public class ContradictionException extends Exception {

    public ContradictionException(String message) {}
}